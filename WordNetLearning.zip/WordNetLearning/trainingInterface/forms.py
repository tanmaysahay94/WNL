from django import forms

class OptionForm(forms.Form):
    def __init__(self, *args, **kwargs):
        options = kwargs.pop('options')
        super(OptionForm, self).__init__(*args, **kwargs)
        self.fields['toChoose'] = forms.ChoiceField(choices=options, widget=forms.RadioSelect)
