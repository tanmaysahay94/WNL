from django.shortcuts import render, render_to_response
from django.http import HttpResponse
import random
from nltk.corpus import wordnet as wn
from .forms import OptionForm
from trainingInterface.models import Record
from django.views.decorators.csrf import csrf_protect

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

# Create your views here.
def foo(request):
    def process(text):
        _text = ' '.join(text.strip().split())
        breakpoints = []
        ret = []
        import string
        for idx in xrange(1, len(_text) - 1):
            prev = _text[idx - 1]
            curr = _text[idx]
            next = _text[idx + 1]
            if prev in string.ascii_lowercase + string.punctuation and next not in string.ascii_lowercase + string.punctuation and curr == ' ':
                breakpoints.append(idx)
        breakpoints.append(len(_text))
        start = 0
        for idx in breakpoints:
            ret.append(_text[start:idx])
            start = idx + 1
        return ret[1:]
    word = random.choice(Record.objects.all().filter(sense=None))
    _word = dict()
    _word['hindi_word']  = word.hindi_word
    _word['english_meaning'] = word.english_meaning
    toProcess = word.examples[:]
    _word['examples'] = process(toProcess)
    senses = wn.synsets(word.english_meaning)
    lines = ((i, "{}. {}, [{}]".format(i, sense.lexname(), ', '.join(sense.lemma_names()))) for i, sense in enumerate(senses))
    form = OptionForm(request.POST or None, options=lines)
    if request.method == 'POST':
        print request.POST['correct_sense'], request.POST['hindi_word']
        update_word = Record.objects.filter(hindi_word = request.POST['hindi_word'])[0]
        update_word.sense = int(request.POST['correct_sense'])
        update_word.save()
    return render(request, 'form.html', {'form':form, 'metadata':_word})
